"""Product-centered mutation contracts for the v2 backend prototype."""

from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json
import re
from typing import Any
from uuid import UUID


TEXT_LIMITS = {"name": 200, "description": 4000, "categoryName": 100}
REQUEST_FIELDS = {"productId", "expectedVersion", "operationId", "changes", "reason"}


class BackendError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def require_text(value: Any, field: str, limit: int) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise BackendError(
            "invalid_request", f"{field} must contain 1-{limit} characters."
        )
    return value.strip()


def validate_product_id(product_id: Any) -> str:
    if not isinstance(product_id, str) or not re.fullmatch(
        r"[a-zA-Z0-9_-]{1,100}", product_id
    ):
        raise BackendError("invalid_request", "productId must be a stable identifier.")
    return product_id


def caller_identity(my_context: Any) -> dict:
    try:
        user = my_context.executing_user
        actor = {
            "tenantId": str(UUID(user["TenantId"])),
            "oid": str(UUID(user["Oid"])),
        }
        username = user.get("PreferredUsername")
        if isinstance(username, str) and username:
            actor["username"] = username
        require_text(my_context.invocation_id, "invocationId", 200)
        return actor
    except (AttributeError, KeyError, TypeError, ValueError) as error:
        raise BackendError(
            "unauthenticated", "Verified Fabric caller context is required."
        ) from error


def authorize(actor: dict, grants: dict, action: str) -> None:
    principal = f"{actor['tenantId']}:{actor['oid']}"
    if action not in grants.get(principal, ()):
        raise BackendError("forbidden", "The caller is not authorized for this action.")


def parse_request(payload: Any) -> dict:
    if not isinstance(payload, dict) or set(payload) != REQUEST_FIELDS:
        raise BackendError(
            "invalid_request", "Only the documented mutation fields are accepted."
        )
    request = deepcopy(payload)
    validate_product_id(request["productId"])
    version = request["expectedVersion"]
    if type(version) is not int or version < 1:
        raise BackendError(
            "invalid_request", "expectedVersion must be a positive integer."
        )
    try:
        request["operationId"] = str(UUID(request["operationId"]))
    except (ValueError, TypeError, AttributeError) as error:
        raise BackendError("invalid_request", "operationId must be a UUID.") from error
    request["reason"] = require_text(request["reason"], "reason", 500)
    changes = request["changes"]
    if (
        not isinstance(changes, dict)
        or not changes
        or set(changes) - (set(TEXT_LIMITS) | {"status"})
    ):
        raise BackendError(
            "invalid_request",
            "Only name, description, categoryName and status are editable.",
        )
    for field, value in changes.items():
        if field in TEXT_LIMITS:
            changes[field] = require_text(value, field, TEXT_LIMITS[field])
        elif not isinstance(value, str) or value not in {"active", "deleted"}:
            raise BackendError("invalid_request", "status must be active or deleted.")
    return request


def request_fingerprint(request: dict, actor: dict) -> str:
    content = {
        "request": request,
        "actor": {key: actor[key] for key in ("tenantId", "oid")},
    }
    return sha256(
        json.dumps(content, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def build_mutation(
    product: dict, request: dict, actor: dict, invocation_id: str, occurred_at: str
) -> tuple:
    product_id = request["productId"]
    if (
        product.get("id") != f"product:{product_id}"
        or product.get("productId") != product_id
        or product.get("docType") != "product"
        or product.get("schemaVersion") != 1
        or type(product.get("version")) is not int
        or product.get("status") not in {"active", "deleted"}
    ):
        raise BackendError(
            "invalid_product", "The stored product does not match the v2 contract."
        )
    if product["version"] != request["expectedVersion"]:
        raise BackendError(
            "version_conflict", "Reload the product before applying this change."
        )
    if not product.get("_etag"):
        raise BackendError("missing_etag", "Concurrency metadata is required.")
    changes = request["changes"]
    if product["status"] == "deleted" and changes != {"status": "active"}:
        raise BackendError(
            "deleted_product", "Restore the product before editing its content."
        )
    if changes.get("status") == "deleted" and set(changes) != {"status"}:
        raise BackendError(
            "invalid_request", "Deletion cannot be combined with content edits."
        )
    differences = [
        {
            "path": f"/{field}",
            "oldValue": deepcopy(product.get(field)),
            "newValue": value,
        }
        for field, value in sorted(changes.items())
        if product.get(field) != value
    ]
    if not differences:
        raise BackendError("no_changes", "At least one value must change.")
    action = "ProductUpdated"
    if changes.get("status") == "deleted":
        action = "ProductDeleted"
    elif product["status"] == "deleted":
        action = "ProductRestored"
    next_version = product["version"] + 1
    audit = {
        "id": f"event:{request['operationId']}",
        "docType": "auditEvent",
        "schemaVersion": 1,
        "productId": product_id,
        "action": action,
        "fromVersion": product["version"],
        "toVersion": next_version,
        "occurredAt": occurred_at,
        "actor": deepcopy(actor),
        "changes": differences,
        "reason": request["reason"],
        "operationId": request["operationId"],
        "invocationId": invocation_id,
        "source": {"function": "update_product"},
        "ttl": -1,
    }
    operations = [
        {"op": "set", "path": change["path"], "value": change["newValue"]}
        for change in differences
    ]
    operations.extend(
        [
            {"op": "set", "path": "/version", "value": next_version},
            {"op": "set", "path": "/updatedAt", "value": occurred_at},
            {"op": "set", "path": "/updatedBy", "value": deepcopy(actor)},
        ]
    )
    result = {
        "status": "applied",
        "productId": product_id,
        "version": next_version,
        "eventId": audit["id"],
    }
    receipt = {
        "id": f"operation:{request['operationId']}",
        "docType": "operation",
        "schemaVersion": 1,
        "productId": product_id,
        "fingerprint": request_fingerprint(request, actor),
        "result": result,
        "occurredAt": occurred_at,
        "ttl": -1,
    }
    return operations, audit, receipt


def read_optional(container: Any, item: str, product_id: str) -> dict | None:
    try:
        return container.read_item(item=item, partition_key=product_id)
    except Exception as error:
        if getattr(error, "status_code", None) == 404:
            return None
        raise


def replay_result(receipt: dict, fingerprint: str) -> dict:
    if receipt.get("fingerprint") != fingerprint:
        raise BackendError(
            "operation_conflict",
            "This operationId was already used for a different request or caller.",
        )
    return {**receipt["result"], "replayed": True}


def apply_update(container: Any, payload: dict, my_context: Any, grants: dict) -> dict:
    try:
        actor = caller_identity(my_context)
        authorize(actor, grants, "write")
        request = parse_request(payload)
        product_id = request["productId"]
        operation_id = f"operation:{request['operationId']}"
        fingerprint = request_fingerprint(request, actor)
        existing = read_optional(container, operation_id, product_id)
        if existing is not None:
            return replay_result(existing, fingerprint)
        product = read_optional(container, f"product:{product_id}", product_id)
        if product is None:
            raise BackendError("not_found", "The product does not exist.")
        occurred_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        operations, audit, receipt = build_mutation(
            product, request, actor, my_context.invocation_id, occurred_at
        )
        try:
            container.execute_item_batch(
                batch_operations=[
                    (
                        "patch",
                        (product["id"], operations),
                        {"if_match_etag": product["_etag"]},
                    ),
                    ("create", (audit,), {}),
                    ("create", (receipt,), {}),
                ],
                partition_key=product_id,
            )
        except Exception as error:
            existing = read_optional(container, operation_id, product_id)
            if existing is not None:
                return replay_result(existing, fingerprint)
            status = getattr(error, "status_code", None)
            error_index = getattr(error, "error_index", None)
            responses = getattr(error, "operation_responses", None)
            if (
                isinstance(error_index, int)
                and isinstance(responses, list)
                and 0 <= error_index < len(responses)
            ):
                status = responses[error_index].get("statusCode", status)
            if status in {409, 412}:
                raise BackendError(
                    "version_conflict", "The product changed during this request."
                ) from error
            raise
        return {**receipt["result"], "replayed": False}
    except BackendError as error:
        return {"status": "rejected", "code": error.code, "message": str(error)}
    except Exception:
        return {
            "status": "failed",
            "code": "storage_error",
            "message": "Retry with the same operationId; the outcome may be unknown.",
        }


def public_document(document: dict) -> dict:
    return {key: value for key, value in document.items() if not key.startswith("_")}


def get_product(container: Any, product_id: str, my_context: Any, grants: dict) -> dict:
    authorize(caller_identity(my_context), grants, "read")
    validate_product_id(product_id)
    document = read_optional(container, f"product:{product_id}", product_id)
    if document is None:
        raise BackendError("not_found", "The product does not exist.")
    return public_document(document)


def get_history(
    container: Any,
    product_id: str,
    page_size: int,
    continuation: str,
    my_context: Any,
    grants: dict,
) -> dict:
    authorize(caller_identity(my_context), grants, "read")
    validate_product_id(product_id)
    if type(page_size) is not int or not 1 <= page_size <= 100:
        raise BackendError("invalid_request", "pageSize must be between 1 and 100.")
    if not isinstance(continuation, str) or len(continuation) > 16000:
        raise BackendError("invalid_request", "Invalid history continuation token.")
    pages = container.query_items(
        query="SELECT * FROM c WHERE c.docType = @docType ORDER BY c.occurredAt DESC",
        parameters=[{"name": "@docType", "value": "auditEvent"}],
        partition_key=product_id,
        max_item_count=page_size,
    ).by_page(continuation_token=continuation or None)
    page = next(pages, [])
    return {
        "items": [public_document(document) for document in page],
        "continuationToken": pages.continuation_token or "",
    }


def seed_documents(actor: dict, occurred_at: str, invocation_id: str) -> list:
    samples = [
        ("bike-100", "Bikes", "Trail bike", "Aluminum frame with 21 gears.", 89999),
        (
            "helmet-200",
            "Accessories",
            "Cycling helmet",
            "Adjustable fit with twelve vents.",
            4999,
        ),
        (
            "tent-300",
            "Camping",
            "Two-person tent",
            "Two-person tent with a removable rainfly.",
            15999,
        ),
    ]
    documents = []
    for product_id, category, name, description, price in samples:
        product = {
            "id": f"product:{product_id}",
            "productId": product_id,
            "docType": "product",
            "schemaVersion": 1,
            "version": 1,
            "status": "active",
            "name": name,
            "categoryName": category,
            "description": description,
            "marketing": {"shortDescription": "", "seoKeywords": []},
            "commercial": {"priceMinor": price, "currency": "USD"},
            "createdAt": occurred_at,
            "createdBy": deepcopy(actor),
            "updatedAt": occurred_at,
            "updatedBy": deepcopy(actor),
        }
        reviews = [
            {
                "id": f"review:{product_id}:{index}",
                "docType": "review",
                "schemaVersion": 1,
                "productId": product_id,
                "rating": rating,
                "text": text,
                "source": "synthetic-demo-v1",
                "createdAt": "2026-10-01T00:00:00Z",
            }
            for index, (rating, text) in enumerate(
                [
                    (5, "The description matched what I received."),
                    (3, "The product details could be clearer."),
                ],
                start=1,
            )
        ]
        audit = {
            "id": f"event:seed:{product_id}",
            "docType": "auditEvent",
            "schemaVersion": 1,
            "productId": product_id,
            "action": "ProductCreated",
            "fromVersion": 0,
            "toVersion": 1,
            "actor": deepcopy(actor),
            "occurredAt": occurred_at,
            "invocationId": invocation_id,
            "operationId": f"seed:{product_id}",
            "reason": "Initialize synthetic demo catalog",
            "changes": [{"path": "/", "oldValue": None, "newValue": deepcopy(product)}],
            "source": {"function": "seed_catalog", "datasetVersion": 1},
            "ttl": -1,
        }
        documents.append([product, *reviews, audit])
    return documents


def seed_catalog(container: Any, my_context: Any, grants: dict) -> dict:
    actor = caller_identity(my_context)
    authorize(actor, grants, "seed")
    occurred_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    results = []
    for documents in seed_documents(actor, occurred_at, my_context.invocation_id):
        product = documents[0]
        product_id = product["productId"]
        if read_optional(container, product["id"], product_id) is not None:
            results.append({"productId": product_id, "status": "skipped"})
            continue
        try:
            container.execute_item_batch(
                batch_operations=[
                    ("create", (document,), {}) for document in documents
                ],
                partition_key=product_id,
            )
        except Exception:
            if read_optional(container, product["id"], product_id) is None:
                raise
            results.append({"productId": product_id, "status": "skipped"})
            continue
        results.append({"productId": product_id, "status": "created"})
    return {"items": results}
